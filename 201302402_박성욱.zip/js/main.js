var  register=0;
var myIndex = 0;
var  modal=[1,1,1];




/*introduce 시작 */



function displayLineChart() {

  var data = {
      labels: ["90/91","91/92","92/93","93/94","94/95","95/96","96/97","97/98","98/99","00/01",
      "01/02","02/03","03/04","04/05","05/06","06/07","07/08","08/09","10/11","11/12","12/13",
      "13/14","14/15","15/16","16/17"],
      datasets: [
          {
              label: "Real_Madrid",
              fillColor: "rgba(220,220,220,0.2)",
              strokeColor: "rgba(220,220,220,1)",
              pointColor: "rgba(220,220,220,1)",
              pointStrokeColor: "#fff",
              pointHighlightFill: "#fff",

              pointHighlightStroke: "rgba(220,220,220,1)",
              data: [3,2,2,4,1,6,1,4,2,5,1,3,1,4,2,2,1,1,2,2,2,1,2,2,2,2,1],

          }
      ]
  };
  var ctx = document.getElementById("lineChart").getContext("2d");
  var options = {};
  var lineChart = new Chart(ctx).Line(data, options);
}

  /*구글 맵 부분*/
  function myMap() {
  var mapProp= {
      center:new google.maps.LatLng(40.5,-3.66),
      zoom:5,
  };
  var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
  var myCenter = new google.maps.LatLng(40.5,-3.66);
  var marker = new google.maps.Marker({
    position: myCenter,
    animation: google.maps.Animation.BOUNCE});
  marker.setMap(map);
  google.maps.event.addListener(marker,'click',function() {
  map.setZoom(9);
  map.setCenter(marker.getPosition());
});
  }



/*introduce 끝*/

/*드랍다운*/

function myFunction_1() {


document.getElementById("myDropdown").classList.toggle("show");

if(document.getElementById("before_img").style.display=="block"){             // 본 이미지가 block 인 경우 <-이 경우는 클릭전으로
  document.getElementById("before_img").style.display="none";                 // 클릭 한 후 befofe 이미지를 none으로 바꾸고
  document.getElementById("after_img").style.display="block";                 // after 이미지를 block으로 바꾸어 주었다.
}
else{                                                                         // 클릭된 후 (드랍다운 된 후) 에는 위 경우와 반대로 해주었다.
  document.getElementById("before_img").style.display="block";
  document.getElementById("after_img").style.display="none";
}

}


/*드랍다운 끝*/
//이미지 슬라이드

var slideIndex = 1;
showSlides(slideIndex);

function plusSlides_image(n) {
showSlides(slideIndex += n);
}

function currentSlide(n) {
showSlides(slideIndex = n);
}

function showSlides(n) {
var i;
var slides = document.getElementsByClassName("mySlides");
var dots = document.getElementsByClassName("dot");
if (n > slides.length) {slideIndex = 1}
if (n < 1) {slideIndex = slides.length}
for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
}
for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
}
slides[slideIndex-1].style.display = "block";
dots[slideIndex-1].className += " active";
}




// 자동슬라이드
function autoSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("dot");
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex> slides.length) {slideIndex = 1}
  slides[slideIndex-1].style.display = "block";
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  dots[slideIndex-1].className += " active";                           /*하단 dot 표시 부분*/
  setTimeout(autoSlides, 5000);                                        /*타이머 5초*/
}


/*모달창 시작*/

function reload_1(){                                              //새로고침시 정보 유지
var i;
var img=document.getElementsByClassName("container");
var mod= document.getElementsByClassName("md");
  for(i=0;i<img.length;i++){
 if(sessionStorage.getItem(i)=='none'){                           //sessionStorage에 저장되어 있는 값이 none이면 그 인덱스에
   img[i].style.display= sessionStorage.getItem(i);               //해당하는 값을 가져와 display 값에 넣어줌.
   mod[i].style.display = sessionStorage.getItem(i);              //( 새로고침 하여도 안뜨게 해주려고)

 }

 }
}
function openModal() {                                         //모달창을 연다.

document.getElementById('myModal').style.display = "block";

}

function closeModal() {                                         //모당창에서 이미지 클릭시
document.getElementById('myModal').style.display = "none";
}

var slideIndex_modal = 1;
// showSlides_modal(slideIndex_modal);

function plusSlides_modal(n) {    //n 값은 1 또는 -1

// var delete_img =document.getElementsByClassName("container");

  showSlides_modal(slideIndex_modal+=n);    
}


function currentSlide_modal(n) {                                       //현재 슬라이드를 띄움
showSlides_modal(slideIndex_modal = n);
}


function showSlides_modal(n) {                                         //모달창  켜지지않았을떄 사용
var i;
var slides_modal = document.getElementsByClassName("modal_slide");

if (n > slides_modal.length) {slideIndex_modal = 1}
if (n < 1) {slideIndex_modal = slides_modal.length}
for (i = 0; i < slides_modal.length; i++) {
    slides_modal[i].style.display = "none";                              //none으로 설정 시 보이지 않음
}
if(sessionStorage.getItem(slideIndex_modal-1)==='none'){
  slides_modal[slideIndex_modal-1].sytle.display='none';
}
slides_modal[slideIndex_modal-1].style.display = "block";                //block으로 설정 시 보임.
}

function delete_Function(x){                                               //삭제 (이미지 'x') 이미지 클릭시
  var contain = document.getElementsByClassName("container");            //기본 모달이미지를 변수에 저장( 배열)
  var md = document.getElementsByClassName("modal_slide");

  sessionStorage.setItem(x,"none");                                        //sessionStorage에 set 해주는 부분
  md[x].style.display="none";                                              //모달창 떳을떄도 이미지 안뜨게 하려고
  contain[x].style.display="none";                                        //인덱스에 해당하는 이미지의 style속성에서 display 를 none으로 설정

}


/*모달창 끝*/



/*방명록 시작*/

function add_register() {
  var new_table = document.createElement("TABLE")                     /*새로 추가될 댓글을 표시할 테이블과 버튼 요소 생성 부분*/
  var new_tr_1 = document.createElement("TR");
  var new_tr_2 = document.createElement("TR");
  var new_th = document.createElement("TH");
  var new_td = document.createElement("TD");
  var button = document.createElement("BUTTON");

    new_table.setAttribute('id','new_table');                        /*만들어준 요소에 id 값 부여*/
    new_tr_1.setAttribute('id','new_tr_1');
    new_tr_2.setAttribute('id','new_tr_2'+register);                 /*resister 변수는 전역 변수로 댓글 등록하기 기능 구현시 여러개의 테이블중
                                                                      내가 댓글 쓴 곳을 찾아주게 하는 변수 ( 구분해주는 역할)*/

    new_th.setAttribute('id','new_th');
    new_td.setAttribute('id','new_td');
    button.setAttribute('id','new_button'+register);



    button.setAttribute('onclick',"reply_click("+register+")")              //댓글 등록함수 set

  var th_input1 = document.getElementById("input1").value;                  //입력데이터  : 작성자
  var th_input2 = document.getElementById("input2").value;                  //입력데이터 : 내용


  var node_1 = document.createTextNode(th_input1);
  var node_2 = document.createTextNode(th_input2);


  new_th.appendChild(node_1);                                               //입력받은 내용(작성자)을 append
  new_td.appendChild(node_2);                                               //입력받은 내용(내용)을 append

  new_tr_1.appendChild(new_th);
  new_tr_1.appendChild(new_td);                                             //테이블에 첫 row에 댓글 작성자와 내용을 append
  new_tr_2.appendChild(button);                                             //두번째 row에 button append
  new_table.appendChild(new_tr_1);
  new_table.appendChild(new_tr_2);                                          //테이블 태그에 두개의 row를 append



  new_table.setAttribute('border','1px solid black');                      //새로 생기는 table의 css속성 정의


  new_th.setAttribute('padding','3px');                                     //th의 속성
  new_tr_1.setAttribute('width','1058.4px');                                //row 속성


  new_td.setAttribute('width','1058.4px');
  new_td.setAttribute('height','30px');                                     //data 속성


  document.getElementById("sub_table").appendChild(new_table);
  document.getElementById("new_button"+register).innerHTML="댓글 등록하기";            //button 속성



  document.getElementById("input1").value = "";      //댓글 등록후 입력창 초기화 부분
  document.getElementById("input2").value = "";      //댓글 등록후 입력창 초기화 부분
  register++;                                        //다음 등록을 위하여 구분 인덱스 증가

}
function reply_click(x){                               //댓글 등록하기 버튼 클릭시 함수
var reply = prompt('답글 내용을 입력하세요.');         //prompt 창으로 입력받기
var index = x;                                       //함수 인자로 받은 x는 답글 내용이 들어갈 위치를 결졍 해준다( 중요함!!!!!!!)
document.getElementById("new_tr_2"+index).innerHTML="답변 : "+reply; //getelement하여 innerhtml을 이용하여 내용 입력
}
/*방명록 끝*/
